classdef Velocity < CoordinateSet
    %   Velocity
    %   A coordinate set comprised of X and Y axes
end

