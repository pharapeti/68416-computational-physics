classdef Acceleration < CoordinateSet
    %   Acceleration
    %   A coordinate set comprised of X and Y axes
end
