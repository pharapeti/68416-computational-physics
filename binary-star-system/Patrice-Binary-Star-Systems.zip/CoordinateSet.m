classdef CoordinateSet
    %	CoordinateSet
    %   Defines a set of coordinates
    
    properties
        X
        Y
    end
end

