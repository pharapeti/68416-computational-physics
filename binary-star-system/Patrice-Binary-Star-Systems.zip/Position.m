classdef Position < CoordinateSet
    %   Position
    %   A coordinate set comprised of X and Y axes
end

