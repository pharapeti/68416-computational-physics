classdef Barycenter < CoordinateSet
    %   Barycenter
    %   A coordinate set comprised of X and Y axes
end

